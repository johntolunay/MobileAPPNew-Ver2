//
// Created by Leland Richardson on 12/27/15.
// Copyright (c) 2015 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface AIRMapCoordinate : NSObject

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;

@end